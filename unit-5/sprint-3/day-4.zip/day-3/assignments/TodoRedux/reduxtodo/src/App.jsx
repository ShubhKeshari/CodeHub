
import './App.css'
import TodoForm from './components/TodoForm'

function App() {

  return (
    <>
      <TodoForm/>
    </>
  )
}

export default App
