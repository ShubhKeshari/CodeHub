
export const LOGIN ="LOGIN";
export const FAILED ="FAILED";
export const LOADING ="LOADING";
export const GET_PRODUCTS = "GET_PRODUCTS";

