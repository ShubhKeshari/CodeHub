const actions = {
    SET_THEME: "SET_THEME",
    ADD_TO_CART: "ADD_TO_CART",
    UPDATE_USER: "UPDATE_USER",
  };
  
  export { actions };
  